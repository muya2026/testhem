# Unzip and publish this update

This bundle contains the current site files and sky assets. Run the commands from the repository root so the archive extracts into the right folders.

## If you already have the repository cloned

```bash
cd /path/to/testhem
git switch main
git pull --ff-only origin main
unzip -o /path/to/testhem-update.zip -d .
git status --short
git diff --stat
git add -A
git commit -m "Animate observatory sky"
git push origin main
```

Replace `/path/to/testhem` and `/path/to/testhem-update.zip` with the paths on your computer. Review `git status` before committing. The push is a normal fast-forward push; do not use `--force`.

## If you need a fresh clone

```bash
git clone https://github.com/muya2026/testhem.git
cd testhem
git pull --ff-only origin main
unzip -o /path/to/testhem-update.zip -d .
git status --short
git diff --stat
git add -A
git commit -m "Animate observatory sky"
git push origin main
```

Git will use your normal GitHub authentication. After the push, allow GitHub Pages a short time to rebuild, then check the public site.
